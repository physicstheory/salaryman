# OpenArt shot prompts

These are production prompts, not an official OpenArt API/import schema. No video jobs have been submitted.

Realistic cinematic Salary Man footage based on the supplied actual-game start/end references. Preserve the same named characters, faces, wardrobe, architecture, geography and shot framing. Improve natural material response and lighting without redesigning the scene. Restrained cinema camera, plausible motion, consistent exposure and skin texture. Seiko remains in village clothes through the whole opening; the suit purchase happens AFTER these shots. No anime style, face drift, extra limbs, floating feet, warped windows, invented logos, HUD, watermarks or generated captions. Keep existing brand panels static. Generate one continuous shot, not a montage. Dialogue and overlays are supplied separately.

## 01 — Dawn over Mizuho (4.0 seconds)
Start: `frames/01-mizuho-dawn-start.jpg`
End: `frames/01-mizuho-dawn-end.jpg`

Slow aerial descent and forward drift over the exact Mizuho valley and rice terraces. Dawn haze and natural cloud movement; keep the roads, mountains and houses in the reference positions.

Dialogue:
- +1.4s — Narration / sound: Mizuho. Rice terraces, one road, and a train twice a day.

## 02 — Across the paddies (3.2 seconds)
Start: `frames/02-paddies-title-start.jpg`
End: `frames/02-paddies-title-end.jpg`

A gentle low aerial push over the rice paddies toward the dawn horizon. Preserve the same valley geography. Leave clean space for the editor to add the Salary Man chapter title; do not generate lettering.

Dialogue:
- No scripted dialogue.

## 03 — Seiko leaves home (3.5 seconds)
Start: `frames/03-leaving-home-start.jpg`
End: `frames/03-leaving-home-end.jpg`

Seiko steps naturally out from the timber-and-plaster family home. Keep his brown village workwear, green work gloves and yellow rubber boots; retain the actual hair and face. No briefcase or other accessory absent from the references. Gentle dolly closer.

Dialogue:
- +0.6s — Seiko: Today's the day.
- +2.5s — Mother: Seiko! The train won't wait!

## 04 — Family farewell (3.4 seconds)
Start: `frames/04-family-platform-start.jpg`
End: `frames/04-family-platform-end.jpg`

Slow eye-level push toward the family at the Mizuho halt. Mother waves, father stays restrained, younger sister waves eagerly. Maintain each reference identity, outfit, relative height and position.

Dialogue:
- +0.4s — Mother: Eat properly! And call us every Sunday!

## 05 — His younger sister (2.6 seconds)
Start: `frames/05-sister-start.jpg`
End: `frames/05-sister-end.jpg`

A restrained close-up dolly toward his shorter younger sister as she waves and calls after him. Maintain her reference face and clothing; no age, body or hairstyle changes. Do not turn her into a different child model.

Dialogue:
- +0.2s — Sister: Onii-chan! Bring me something from the city!

## 06 — His father (2.6 seconds)
Start: `frames/06-father-start.jpg`
End: `frames/06-father-end.jpg`

A quiet close-up push toward the father in the same suit and tie. Small facial expression and a restrained nod, no exaggerated acting. Keep the actual face and background geography.

Dialogue:
- +0.5s — Father: …Make us proud, Seiko.

## 07 — Seiko promises (2.8 seconds)
Start: `frames/07-seiko-promise-start.jpg`
End: `frames/07-seiko-promise-end.jpg`

Slow close-up push toward Seiko as he answers his family with a small determined expression. Retain his reference face, short dark hair and village collar. Natural breathing and eye movement; no face redesign.

Dialogue:
- +0.3s — Seiko: I will. I promise.

## 08 — Doors closing (4.0 seconds)
Start: `frames/08-train-interior-start.jpg`
End: `frames/08-train-interior-end.jpg`

Inside the same silver local train: blue longitudinal bench seats, cream walls, hanging circular hand straps and existing ad panels. Seiko sits naturally with his hips supported by the bench and feet directed toward the aisle. Doors close; the train begins to pull away late in the shot. Correct contact and natural anatomy are essential; do not copy an imperfect source seating pose.

Dialogue:
- +0.3s — Narration / sound: ♪ ドアが閉まります。 Doors closing.
- +2.4s — Mother: Seiko! Call us when you get there!

## 09 — The platform slips away (4.2 seconds)
Start: `frames/09-family-through-window-start.jpg`
End: `frames/09-family-through-window-end.jpg`

Over Seiko's shoulder, look out of the train toward the family waving on the platform. Train accelerates smoothly, family becomes smaller; stationary platform and moving carriage stay mechanically coherent. Keep window geometry and the same people; no duplicated family members.

Dialogue:
- +0.4s — Sister: Bye bye, Onii-chan! Byeee!
- +3.0s — Narration / sound: Mizuho.

## 10 — Seiko by the window (3.5 seconds)
Start: `frames/10-seiko-window-start.jpg`
End: `frames/10-seiko-window-end.jpg`

A quiet close-up of Seiko seated by the carriage window. Moving dawn light passes across his unchanged face as the village recedes. Subtle eyes, breathing and train vibration; keep his clothes and the blue bench consistent.

Dialogue:
- +0.5s — Narration / sound: Seiko watched the village until the mountains took it.

## 11 — Out of the valley (4.0 seconds)
Start: `frames/11-train-valley-start.jpg`
End: `frames/11-train-valley-end.jpg`

Exterior tracking aerial of the same THREE-CAR silver local with GREEN stripe travelling along its rails out of Mizuho. Smooth acceleration and increasing camera height. Wheels must remain on the rails; preserve the reference carriage count and valley layout.

Dialogue:
- No scripted dialogue.

## 12 — Tōkonto ahead (5.6 seconds)
Start: `frames/12-tokonto-aerial-start.jpg`
End: `frames/12-tokonto-aerial-end.jpg`

A smooth aerial approach toward the actual Tōkonto skyline and SOTI Tower. Keep the city layout and SOTI's stepped square blue-glass silhouette, stone podium and narrow roof mast. Early morning light, physically plausible glass; no Tokyo Tower, famous real landmarks or invented futuristic skyline.

Dialogue:
- +0.8s — Narration / sound: Tōkonto.
- +1.5s — Narration / sound: Fourteen million people. And somewhere in it, a job with his name on it.

## 13 — Transition into the waking scene (2.2 seconds)
Start: `frames/13-city-white-transition-start.jpg`
End: `frames/13-city-white-transition-end.jpg`

Continue the city approach with the same geometry and morning light. Generate a clean city plate; the editor will add the final white transition. Do not replace the entire image with white or generate an abrupt flash.

Dialogue:
- No scripted dialogue.

## 14 — Waking at Central (3.6 seconds)
Start: `frames/14-waking-on-bench-start.jpg`
End: `frames/14-waking-on-bench-end.jpg`

Seiko dozes on the concourse bench at Tōkonto Central, then stirs when his phone vibrates. Preserve the actual room layout, glass roof, beam positions, signs and bench. Begin with a natural supported seated pose, head lowered, rather than a floating or standing source-model pose.

Dialogue:
- +1.2s — Narration / sound: *bzzt* *bzzt*

## 15 — He recognises the station (4.4 seconds)
Start: `frames/15-recognising-central-start.jpg`
End: `frames/15-recognising-central-end.jpg`

Seiko sits up on the bench and looks around, recognising Tōkonto Central. Commuters cross naturally behind him. Keep his same village outfit and facial identity, realistic seated weight and hand placement.

Dialogue:
- +0.3s — Seiko: Huh…? Where—
- +2.0s — Seiko: Tōkonto Central. I made it.

## 16 — The interview message (6.5 seconds)
Start: `frames/16-peek-invitation-start.jpg`
End: `frames/16-peek-invitation-end.jpg`

Close, restrained camera move as seated Seiko checks his phone and reacts with surprised hope. Maintain the same actual face, clothes and station. Keep the phone screen stable and unlettered; the exact Peek interview message is supplied separately for compositing, not AI-generated text.

Dialogue:
- +0.4s — Narration / sound: Peek — 1 new message
- +2.2s — Seiko: SOTI… SOTI wants to meet me?!

## 17 — He needs a suit (4.2 seconds)
Start: `frames/17-dress-sharp-start.jpg`
End: `frames/17-dress-sharp-end.jpg`

Seiko glances down at his village workwear, realises he needs to dress for the interview, and prepares to stand. Preserve the existing bench and station; no instant wardrobe change, no suit transformation. End ready to hand off to gameplay.

Dialogue:
- +0.2s — Seiko: “Dress sharp.”
- +1.8s — Seiko: …In these? I need to freshen up.

